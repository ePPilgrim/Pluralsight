from .icar import ICar

class JeepSahara(ICar):
    
    def start(self):
        print('JeepSahara running with shocking power!')
    
    def stop(self):
        print('JeepSahara shutting down.')