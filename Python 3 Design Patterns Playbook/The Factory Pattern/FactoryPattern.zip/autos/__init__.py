from .factories.loader import load_factory
from .simplefactory.autofactory import AutoFactory